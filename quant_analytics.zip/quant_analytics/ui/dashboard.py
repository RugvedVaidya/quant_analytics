import time
import requests
import pandas as pd
import streamlit as st
import plotly.graph_objects as go

# -------------------------------------------------
# Page Config
# -------------------------------------------------
st.set_page_config(
    page_title="Pair Trading Dashboard",
    layout="wide"
)

st.title("📊 Real-Time Pair Trading Analytics")

BACKEND_URL = "http://127.0.0.1:8000"

# -------------------------------------------------
# Sidebar Controls
# -------------------------------------------------
st.sidebar.header("Controls")

symbol_a = st.sidebar.selectbox("Symbol A", ["btcusdt"])
symbol_b = st.sidebar.selectbox("Symbol B", ["ethusdt"])
timeframe = st.sidebar.selectbox("Timeframe", ["1s", "1m", "5m"], index=1)

window = st.sidebar.slider("Rolling Window (bars)", 10, 100, 50)
z_thresh = st.sidebar.slider("Z-Score Threshold", 1.0, 3.0, 2.0)
refresh = st.sidebar.slider("Refresh (seconds)", 5, 30, 10)

# -------------------------------------------------
# Auto Refresh (Streamlit-safe)
# -------------------------------------------------
if "last_refresh" not in st.session_state:
    st.session_state.last_refresh = time.time()

if time.time() - st.session_state.last_refresh > refresh:
    st.session_state.last_refresh = time.time()
    st.rerun()


# -------------------------------------------------
# API Helpers
# -------------------------------------------------
def get_bars(symbol):
    r = requests.get(
        f"{BACKEND_URL}/bars",
        params={"symbol": symbol, "timeframe": timeframe},
        timeout=5
    )
    r.raise_for_status()
    return r.json()

def get_zscore():
    r = requests.get(
        f"{BACKEND_URL}/analytics/zscore",
        params={
            "symbol_a": symbol_a,
            "symbol_b": symbol_b,
            "timeframe": timeframe,
            "window": window
        },
        timeout=5
    )
    r.raise_for_status()
    return r.json()

def get_correlation():
    r = requests.get(
        f"{BACKEND_URL}/analytics/correlation",
        params={
            "symbol_a": symbol_a,
            "symbol_b": symbol_b,
            "timeframe": timeframe,
            "window": window
        },
        timeout=5
    )
    r.raise_for_status()
    return r.json()

def get_adf():
    r = requests.get(
        f"{BACKEND_URL}/analytics/adf",
        params={
            "symbol_a": symbol_a,
            "symbol_b": symbol_b,
            "timeframe": timeframe
        },
        timeout=5
    )
    r.raise_for_status()
    return r.json()

def get_alert():
    r = requests.get(
        f"{BACKEND_URL}/alerts/zscore",
        params={
            "symbol_a": symbol_a,
            "symbol_b": symbol_b,
            "timeframe": timeframe,
            "window": window
        },
        timeout=5
    )
    r.raise_for_status()
    return r.json()

# -------------------------------------------------
# Fetch Data
# -------------------------------------------------
try:
    bars_a = get_bars(symbol_a)
    bars_b = get_bars(symbol_b)
    zdata = get_zscore()
    cdata = get_correlation()
    adfdata = get_adf()
    alert = get_alert()
except Exception as e:
    st.error(f"Backend not reachable: {e}")
    st.stop()

# -------------------------------------------------
# DataFrames
# -------------------------------------------------
df_a = pd.DataFrame(bars_a["data"])
df_b = pd.DataFrame(bars_b["data"])

if df_a.empty or df_b.empty:
    st.warning("Waiting for data...")
    st.stop()

df_a.index = pd.to_datetime(df_a.index)
df_b.index = pd.to_datetime(df_b.index)

df = df_a.join(df_b, lsuffix="_a", rsuffix="_b", how="inner")

# -------------------------------------------------
# Metrics
# -------------------------------------------------
c1, c2, c3, c4 = st.columns(4)
c1.metric("Hedge Ratio", f"{zdata['hedge_ratio']:.4f}" if zdata["hedge_ratio"] else "N/A")
c2.metric("Z-Score", f"{zdata['zscore']:.2f}" if zdata["zscore"] else "N/A")
c3.metric("Correlation", f"{cdata['correlation']:.2f}" if cdata["correlation"] else "N/A")
c4.metric("ADF p-value", f"{adfdata['p_value']:.4f}" if adfdata["p_value"] else "N/A")

# -------------------------------------------------
# Alert Banner
# -------------------------------------------------
if alert["triggered"]:
    direction = "BUY spread" if zdata["zscore"] < 0 else "SELL spread"
    st.error(f"🚨 PAIR TRADING ALERT — {direction}")

# -------------------------------------------------
# Price Chart
# -------------------------------------------------
price_fig = go.Figure()
price_fig.add_trace(go.Scatter(x=df.index, y=df["close_a"], name=symbol_a.upper()))
price_fig.add_trace(go.Scatter(x=df.index, y=df["close_b"], name=symbol_b.upper()))
price_fig.update_layout(title="Prices")
st.plotly_chart(price_fig, use_container_width=True)

# -------------------------------------------------
# Spread Chart
# -------------------------------------------------
# -------------------------------------------------
# Spread Chart (SAFE)
# -------------------------------------------------
hedge = zdata.get("hedge_ratio")

spread_fig = go.Figure()

if hedge is not None:
    spread_values = df["close_a"] - hedge * df["close_b"]

    spread_fig.add_trace(go.Scatter(
        x=df.index,
        y=spread_values,
        name="Spread"
    ))
else:
    spread_fig.add_annotation(
        text="Waiting for sufficient data to compute hedge ratio",
        xref="paper",
        yref="paper",
        showarrow=False,
        font=dict(size=14)
    )

spread_fig.update_layout(title="Spread")
st.plotly_chart(spread_fig, use_container_width=True)


# -------------------------------------------------
# Z-Score Chart
# -------------------------------------------------
# -------------------------------------------------
# Z-Score Chart (VISUAL ONLY)
# -------------------------------------------------
hedge = zdata.get("hedge_ratio")

z_fig = go.Figure()

if hedge is not None and len(df) >= window:
    spread_series = df["close_a"] - hedge * df["close_b"]

    z_series = (
        spread_series - spread_series.rolling(window).mean()
    ) / spread_series.rolling(window).std()

    z_fig.add_trace(go.Scatter(
        x=df.index,
        y=z_series,
        name="Z-Score"
    ))
else:
    z_fig.add_annotation(
        text="Waiting for sufficient data to compute Z-Score",
        xref="paper",
        yref="paper",
        showarrow=False,
        font=dict(size=14)
    )

z_fig.add_hline(y=z_thresh, line_dash="dash", line_color="red")
z_fig.add_hline(y=-z_thresh, line_dash="dash", line_color="red")
z_fig.update_layout(title="Z-Score")

st.plotly_chart(z_fig, use_container_width=True)

